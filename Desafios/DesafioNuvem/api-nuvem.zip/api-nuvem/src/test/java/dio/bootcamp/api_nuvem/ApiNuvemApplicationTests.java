package dio.bootcamp.api_nuvem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiNuvemApplicationTests {

	@Test
	void contextLoads() {
	}

}
