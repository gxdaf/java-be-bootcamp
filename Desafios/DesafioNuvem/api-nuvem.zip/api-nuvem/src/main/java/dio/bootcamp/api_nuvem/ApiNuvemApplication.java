package dio.bootcamp.api_nuvem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiNuvemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiNuvemApplication.class, args);
	}

}
